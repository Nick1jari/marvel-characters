"""Marvel characters models package."""
